from fastapi import APIRouter, Depends, HTTPException
from app.dependencias import obtener_usuario_actual
from fastapi.responses import FileResponse
import os

router = APIRouter(prefix="/resultados", tags=["Resultados"])
RESULTADOS_ESCANEO = []

@router.post("/guardar")
def guardar_resultado(resultados: dict, usuario=Depends(obtener_usuario_actual)):
    entrada = {
        "usuario": usuario["sub"],
        "resultados": resultados
    }
    RESULTADOS_ESCANEO.append(entrada)
    return {"mensaje": "✅ Resultados almacenados correctamente."}

@router.get("/listar-informes")
def listar_informes(usuario=Depends(obtener_usuario_actual)):
    base = "./informes"
    archivos = []
    for f in os.listdir(base):
        if usuario["sub"] in f:
            archivos.append({
                "nombre": f,
                "url": f"http://localhost:8000/resultados/descargar/{f}"
            })
    return archivos

@router.get("/descargar/{archivo}")
def descargar_informe(archivo: str, usuario=Depends(obtener_usuario_actual)):
    path = os.path.join("./informes", archivo)
    if usuario["sub"] not in archivo:
        raise HTTPException(status_code=403, detail="Acceso denegado.")
    return FileResponse(path, filename=archivo, media_type="application/pdf")