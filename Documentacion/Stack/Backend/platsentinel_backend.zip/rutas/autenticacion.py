from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from jose import jwt
from datetime import datetime, timedelta
from app.configuracion import settings

router = APIRouter(prefix="/auth", tags=["Autenticación"])

usuarios = {
    "admin": {"username": "admin", "password": "segura123", "rol": "admin"},
    "tecnico": {"username": "tecnico", "password": "token456", "rol": "tecnico"}
}

@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = usuarios.get(form_data.username)
    if not user or user["password"] != form_data.password:
        raise HTTPException(status_code=401, detail="Credenciales inválidas")

    expiration = datetime.utcnow() + timedelta(minutes=settings.duracion_token)
    payload = {
        "sub": user["username"],
        "rol": user["rol"],
        "exp": expiration
    }

    token_jwt = jwt.encode(payload, settings.clave_jwt, algorithm=settings.algoritmo_jwt)
    return {
        "access_token": token_jwt,
        "token_type": "bearer"
    }