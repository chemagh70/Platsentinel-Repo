<template>
  <div class="container">
    <h1>📊 Dashboard SentinelCore</h1>
    <p>Bienvenido, selecciona una opción:</p>
    <router-link to="/informes">📄 Ver Informes</router-link>
  </div>
</template>

<script>
export default {
  name: 'Dashboard'
}
</script>