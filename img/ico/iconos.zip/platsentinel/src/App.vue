<template>
  <!-- Contenedor principal que organiza la barra lateral y el contenido principal -->
  <div class="app-container">
    <!-- Barra lateral que contiene el logo y la navegación, con clase dinámica para colapsar -->
    <aside class="sidebar" :class="{ 'collapsed': isCollapsed }">
      <!-- Encabezado de la barra lateral con logo -->
      <div class="sidebar-header">
        <img src="./assets/logo_r.png" alt="PlatSentinel Logo" class="logo" />
      </div>
      <!-- Navegación con enlaces a las diferentes secciones, cada uno con su icono -->
      <nav>
        <router-link to="/" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/inicio.svg" class="nav-icon" alt="Inicio" />
          <span>Inicio</span>
        </router-link>
        <router-link to="/dashboard" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/dashboard.svg" class="nav-icon" alt="Dashboard" />
          <span>Dashboard</span>
        </router-link>
        <router-link to="/escaneo-red" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/escaneo-red.svg" class="nav-icon" alt="Escaneo de Red" />
          <span>Escaneo de Red</span>
        </router-link>
        <router-link to="/tokens" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/tokens.svg" class="nav-icon" alt="Tokens" />
          <span>Tokens</span>
        </router-link>
        <router-link to="/deteccion-riesgos" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/deteccion-riesgos.svg" class="nav-icon" alt="Detección de Riesgos" />
          <span>Detección de Riesgos</span>
        </router-link>
        <router-link to="/analisis-vulnerabilidades" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/analisis-vulnerabilidades.svg" class="nav-icon" alt="Análisis de Vulnerabilidades" />
          <span>Análisis de Vulnerabilidades</span>
        </router-link>
        <router-link to="/gestion-riesgos" @click="isCollapsed = false" class="nav-item">
          <img src="./assets/ico/gestion-riesgo.svg" class="nav-icon" alt="Gestión de Riesgos" />
          <span>Gestión de Riesgos</span>
        </router-link>
      </nav>
      <!-- Botón de colapso/expansión en la parte inferior con imágenes -->
      <div class="sidebar-footer">
        <button @click="toggleSidebar" class="toggle-btn">
          <img :src="isCollapsed ? './src/assets/flecha_r.png' : './src/assets/flecha_v.png'" alt="Toggle Sidebar" />
        </button>
      </div>
    </aside>
    <!-- Contenido principal que se ajusta al espacio restante -->
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup>
  import { ref } from 'vue';

  const isCollapsed = ref(false);

  function toggleSidebar() {
    isCollapsed.value = !isCollapsed.value;
  }
</script>

<style scoped>
  .app-container {
    display: flex;
    height: 100vh;
    margin: 0;
  }
  .sidebar {
    width: 225px;
    background-color: #2c3e50;
    color: #ecf0f1;
    transition: width 0.3s;
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }
  .sidebar.collapsed {
    width: 50px;
  }
  .sidebar-header {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #34495e;
    margin: 0;
  }
  .logo {
    height: 40px;
    align-items: center;
    transition: filter 300ms;
  }
  .logo:hover {
    filter: brightness(1.2);
  }
  .sidebar-footer {
    margin-top: auto;
    padding: 0.5rem;
    border-top: 1px solid #34495e;
    text-align: right;
  }
  .sidebar.collapsed .sidebar-footer {
    text-align: left;
  }
  .toggle-btn {
    background: none;
    border: none;
    cursor: pointer;
    margin: 0;
    padding: 0;
    outline: none;
  }
  .toggle-btn img {
    height: 20px;
    transition: transform 0.3s;
  }
  nav {
    padding: 2rem 0;
    margin: 0;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    text-align: left;
  }
  .nav-item {
    display: flex;
    align-items: center;
    justify-content: left;
    width: 100%;
    padding: 0.75rem 1rem;
    color: #ecf0f1;
    text-decoration: none;
    font-weight: 500;
    transition: background-color 0.3s;
    margin: 0;
  }
  .nav-item:hover {
    background-color: #34495e;
  }
  .nav-item.router-link-active {
    background-color: #3498db;
  }
  .nav-icon {
    width: 20px;
    height: 20px;
    margin-right: 12px;
    vertical-align: middle;
    filter: brightness(1.1);
    flex-shrink: 0;
  }
  .sidebar.collapsed .nav-icon {
    margin-right: 0;
  }
  .sidebar.collapsed .nav-item span {
    display: none;
  }
  .main-content {
    margin-left: 225px;
    padding: 2rem;
    width: calc(100% - 225px);
    transition: margin-left 0.3s, width 0.3s;
    margin-top: 0;
    margin-bottom: 0;
  }
  .sidebar.collapsed + .main-content {
    margin-left: 50px;
    width: calc(100% - 50px);
  }
  @media (max-width: 768px) {
    .sidebar {
      width: 50px;
      transition: width 0.3s;
    }
    .sidebar.collapsed {
      width: 225px;
    }
    .main-content {
      margin-left: 50px;
      width: calc(100% - 50px);
    }
    .sidebar.collapsed + .main-content {
      margin-left: 225px;
      width: calc(100% - 225px);
    }
  }
  @media (min-width: 768px) and (max-width: 1024px) {
    .sidebar {
      width: 200px;
    }
    .sidebar.collapsed {
      width: 50px;
    }
    .main-content {
      margin-left: 200px;
      width: calc(100% - 200px);
    }
    .sidebar.collapsed + .main-content {
      margin-left: 50px;
      width: calc(100% - 50px);
    }
  }
  @media (min-width: 1025px) {
    .sidebar {
      width: 250px;
    }
    .sidebar.collapsed {
      width: 60px;
    }
    .main-content {
      margin-left: 250px;
      width: calc(100% - 250px);
    }
    .sidebar.collapsed + .main-content {
      margin-left: 60px;
      width: calc(100% - 60px);
    }
  }
</style>